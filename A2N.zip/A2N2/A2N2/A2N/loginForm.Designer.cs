﻿namespace A2N
{
    partial class loginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UsernameLabel = new Label();
            PasswordLabel = new Label();
            usernameTxtbox = new TextBox();
            passwordTxtbox = new TextBox();
            loginBtn = new Button();
            backBtn = new Button();
            label1 = new Label();
            label2 = new Label();
            checkBox1 = new CheckBox();
            panel1 = new Panel();
            button3 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.Location = new Point(56, 154);
            UsernameLabel.Margin = new Padding(4, 0, 4, 0);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(89, 23);
            UsernameLabel.TabIndex = 2;
            UsernameLabel.Text = "Username";
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.Location = new Point(56, 230);
            PasswordLabel.Margin = new Padding(4, 0, 4, 0);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(84, 23);
            PasswordLabel.TabIndex = 3;
            PasswordLabel.Text = "Password";
            // 
            // usernameTxtbox
            // 
            usernameTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            usernameTxtbox.BorderStyle = BorderStyle.None;
            usernameTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            usernameTxtbox.Location = new Point(56, 187);
            usernameTxtbox.Margin = new Padding(4, 3, 4, 3);
            usernameTxtbox.Multiline = true;
            usernameTxtbox.Name = "usernameTxtbox";
            usernameTxtbox.Size = new Size(247, 40);
            usernameTxtbox.TabIndex = 4;
            usernameTxtbox.TextChanged += UsernameTxtbox_TextChanged;
            // 
            // passwordTxtbox
            // 
            passwordTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            passwordTxtbox.BorderStyle = BorderStyle.None;
            passwordTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            passwordTxtbox.Location = new Point(56, 256);
            passwordTxtbox.Margin = new Padding(4, 3, 4, 3);
            passwordTxtbox.Multiline = true;
            passwordTxtbox.Name = "passwordTxtbox";
            passwordTxtbox.PasswordChar = '*';
            passwordTxtbox.Size = new Size(247, 40);
            passwordTxtbox.TabIndex = 5;
            // 
            // loginBtn
            // 
            loginBtn.BackColor = Color.FromArgb(116, 86, 174);
            loginBtn.ForeColor = Color.White;
            loginBtn.Location = new Point(53, 338);
            loginBtn.Margin = new Padding(4, 3, 4, 3);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(247, 40);
            loginBtn.TabIndex = 6;
            loginBtn.Text = "Log in";
            loginBtn.UseVisualStyleBackColor = false;
            loginBtn.Click += loginBtn_Click;
            // 
            // backBtn
            // 
            backBtn.BackColor = Color.White;
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 86, 174);
            backBtn.Location = new Point(81, 441);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(174, 40);
            backBtn.TabIndex = 7;
            backBtn.Text = "Create An Account";
            backBtn.UseVisualStyleBackColor = false;
            backBtn.Click += backBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(56, 410);
            label1.Name = "label1";
            label1.Size = new Size(229, 28);
            label1.TabIndex = 8;
            label1.Text = "Dont Have An Account";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(116, 86, 174);
            label2.Location = new Point(56, 67);
            label2.Name = "label2";
            label2.Size = new Size(135, 34);
            label2.TabIndex = 9;
            label2.Text = "SIGN IN";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Cursor = Cursors.Hand;
            checkBox1.FlatStyle = FlatStyle.Flat;
            checkBox1.Location = new Point(152, 305);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(151, 27);
            checkBox1.TabIndex = 22;
            checkBox1.Text = "Show Password";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button3);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(359, 47);
            panel1.TabIndex = 45;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Right;
            button3.FlatAppearance.BorderSize = 0;
            button3.Location = new Point(265, 0);
            button3.Name = "button3";
            button3.Size = new Size(94, 47);
            button3.TabIndex = 0;
            button3.Text = "X";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // loginForm
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(359, 497);
            Controls.Add(panel1);
            Controls.Add(checkBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(backBtn);
            Controls.Add(loginBtn);
            Controls.Add(passwordTxtbox);
            Controls.Add(usernameTxtbox);
            Controls.Add(PasswordLabel);
            Controls.Add(UsernameLabel);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "loginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "loginForm";
            Load += loginForm_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label UsernameLabel;
        private Label PasswordLabel;
        private TextBox usernameTxtbox;
        private TextBox passwordTxtbox;
        private Button loginBtn;
        private Button backBtn;
        private Label label1;
        private Label label2;
        private CheckBox checkBox1;
        private Panel panel1;
        private Button button3;
    }
}