﻿namespace A2N
{
    partial class admininsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button2 = new Button();
            label2 = new Label();
            idTxtbox = new TextBox();
            nameTxtbox = new TextBox();
            carbTxtbox = new TextBox();
            label3 = new Label();
            fatTxtbox = new TextBox();
            label4 = new Label();
            protienTxtbox = new TextBox();
            label5 = new Label();
            caloriesTxtbox = new TextBox();
            label6 = new Label();
            label7 = new Label();
            typeCombobox = new ComboBox();
            UsernameLabel = new Label();
            label1 = new Label();
            backBtn = new Button();
            applyBtn = new Button();
            QuantityTxtbox = new TextBox();
            label8 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(408, 47);
            panel1.TabIndex = 25;
            panel1.Paint += panel1_Paint;
            // 
            // button2
            // 
            button2.Dock = DockStyle.Right;
            button2.FlatAppearance.BorderSize = 0;
            button2.Location = new Point(314, 0);
            button2.Name = "button2";
            button2.Size = new Size(94, 47);
            button2.TabIndex = 0;
            button2.Text = "X";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(116, 86, 174);
            label2.Location = new Point(12, 92);
            label2.Name = "label2";
            label2.Size = new Size(202, 34);
            label2.TabIndex = 26;
            label2.Text = "Admin Panel";
            // 
            // idTxtbox
            // 
            idTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            idTxtbox.BorderStyle = BorderStyle.None;
            idTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            idTxtbox.Location = new Point(12, 177);
            idTxtbox.Margin = new Padding(4, 3, 4, 3);
            idTxtbox.Multiline = true;
            idTxtbox.Name = "idTxtbox";
            idTxtbox.Size = new Size(157, 33);
            idTxtbox.TabIndex = 28;
            // 
            // nameTxtbox
            // 
            nameTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            nameTxtbox.BorderStyle = BorderStyle.None;
            nameTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            nameTxtbox.Location = new Point(12, 254);
            nameTxtbox.Margin = new Padding(4, 3, 4, 3);
            nameTxtbox.Multiline = true;
            nameTxtbox.Name = "nameTxtbox";
            nameTxtbox.Size = new Size(363, 40);
            nameTxtbox.TabIndex = 30;
            // 
            // carbTxtbox
            // 
            carbTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            carbTxtbox.BorderStyle = BorderStyle.None;
            carbTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            carbTxtbox.Location = new Point(12, 336);
            carbTxtbox.Margin = new Padding(4, 3, 4, 3);
            carbTxtbox.Multiline = true;
            carbTxtbox.Name = "carbTxtbox";
            carbTxtbox.Size = new Size(156, 40);
            carbTxtbox.TabIndex = 32;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 303);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(48, 23);
            label3.TabIndex = 31;
            label3.Text = "Carb";
            // 
            // fatTxtbox
            // 
            fatTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            fatTxtbox.BorderStyle = BorderStyle.None;
            fatTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            fatTxtbox.Location = new Point(218, 336);
            fatTxtbox.Margin = new Padding(4, 3, 4, 3);
            fatTxtbox.Multiline = true;
            fatTxtbox.Name = "fatTxtbox";
            fatTxtbox.Size = new Size(156, 40);
            fatTxtbox.TabIndex = 34;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(218, 303);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(34, 23);
            label4.TabIndex = 33;
            label4.Text = "Fat";
            // 
            // protienTxtbox
            // 
            protienTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            protienTxtbox.BorderStyle = BorderStyle.None;
            protienTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            protienTxtbox.Location = new Point(12, 402);
            protienTxtbox.Margin = new Padding(4, 3, 4, 3);
            protienTxtbox.Multiline = true;
            protienTxtbox.Name = "protienTxtbox";
            protienTxtbox.Size = new Size(156, 40);
            protienTxtbox.TabIndex = 36;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(11, 376);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(68, 23);
            label5.TabIndex = 35;
            label5.Text = "Protien";
            // 
            // caloriesTxtbox
            // 
            caloriesTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            caloriesTxtbox.BorderStyle = BorderStyle.None;
            caloriesTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            caloriesTxtbox.Location = new Point(218, 402);
            caloriesTxtbox.Margin = new Padding(4, 3, 4, 3);
            caloriesTxtbox.Multiline = true;
            caloriesTxtbox.Name = "caloriesTxtbox";
            caloriesTxtbox.Size = new Size(156, 40);
            caloriesTxtbox.TabIndex = 38;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(218, 376);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(73, 23);
            label6.TabIndex = 37;
            label6.Text = "Calories";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(219, 144);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(48, 23);
            label7.TabIndex = 40;
            label7.Text = "Type";
            // 
            // typeCombobox
            // 
            typeCombobox.BackColor = Color.FromArgb(230, 231, 233);
            typeCombobox.Cursor = Cursors.Hand;
            typeCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeCombobox.FlatStyle = FlatStyle.Flat;
            typeCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            typeCombobox.FormattingEnabled = true;
            typeCombobox.Items.AddRange(new object[] { "BreakFast", "Lunch", "Dinner" });
            typeCombobox.Location = new Point(218, 179);
            typeCombobox.Margin = new Padding(4, 3, 4, 3);
            typeCombobox.Name = "typeCombobox";
            typeCombobox.Size = new Size(157, 31);
            typeCombobox.TabIndex = 39;
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.Location = new Point(12, 144);
            UsernameLabel.Margin = new Padding(4, 0, 4, 0);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(67, 23);
            UsernameLabel.TabIndex = 27;
            UsernameLabel.Text = "MealID";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 221);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(96, 23);
            label1.TabIndex = 29;
            label1.Text = "MealName";
            // 
            // backBtn
            // 
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 85, 174);
            backBtn.Location = new Point(11, 546);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(210, 56);
            backBtn.TabIndex = 57;
            backBtn.Text = "Back To Choosing Page";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // applyBtn
            // 
            applyBtn.BackColor = Color.FromArgb(116, 86, 174);
            applyBtn.ForeColor = Color.White;
            applyBtn.Location = new Point(212, 474);
            applyBtn.Margin = new Padding(4, 3, 4, 3);
            applyBtn.Name = "applyBtn";
            applyBtn.Size = new Size(163, 41);
            applyBtn.TabIndex = 77;
            applyBtn.Text = "Apply";
            applyBtn.UseVisualStyleBackColor = false;
            applyBtn.Click += applyBtn_Click;
            // 
            // QuantityTxtbox
            // 
            QuantityTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            QuantityTxtbox.BorderStyle = BorderStyle.None;
            QuantityTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            QuantityTxtbox.Location = new Point(13, 474);
            QuantityTxtbox.Margin = new Padding(4, 3, 4, 3);
            QuantityTxtbox.Multiline = true;
            QuantityTxtbox.Name = "QuantityTxtbox";
            QuantityTxtbox.Size = new Size(156, 40);
            QuantityTxtbox.TabIndex = 79;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 448);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(80, 23);
            label8.TabIndex = 78;
            label8.Text = "Quantity";
            // 
            // admininsert
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(408, 614);
            Controls.Add(QuantityTxtbox);
            Controls.Add(label8);
            Controls.Add(applyBtn);
            Controls.Add(backBtn);
            Controls.Add(label7);
            Controls.Add(typeCombobox);
            Controls.Add(caloriesTxtbox);
            Controls.Add(label6);
            Controls.Add(protienTxtbox);
            Controls.Add(label5);
            Controls.Add(fatTxtbox);
            Controls.Add(label4);
            Controls.Add(carbTxtbox);
            Controls.Add(label3);
            Controls.Add(nameTxtbox);
            Controls.Add(label1);
            Controls.Add(idTxtbox);
            Controls.Add(UsernameLabel);
            Controls.Add(label2);
            Controls.Add(panel1);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "admininsert";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "  w";
            Load += adminform_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button2;
        private Label label2;
        private TextBox idTxtbox;
        private TextBox nameTxtbox;
        private TextBox carbTxtbox;
        private Label label3;
        private TextBox fatTxtbox;
        private Label label4;
        private TextBox protienTxtbox;
        private Label label5;
        private TextBox caloriesTxtbox;
        private Label label6;
        private Label label7;
        private ComboBox typeCombobox;
        private Label UsernameLabel;
        private Label label1;
        private Button backBtn;
        private Button applyBtn;
        private TextBox QuantityTxtbox;
        private Label label8;
    }
}