﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace A2N
{
    public partial class admindelete : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;
        public admindelete()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            panel1.MouseDown += Panel1_MouseDown;
            panel1.MouseMove += Panel1_MouseMove;
            panel1.MouseUp += Panel1_MouseUp;
        }

        protected override void WndProc(ref Message m)
        {
            const int cgrip = 16;
            const int cCaption = 32;

            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cgrip && pos.Y >= this.ClientSize.Height - cgrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                this.Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new adminchoose().Show();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string id = idTxtbox.Text;
                string type = typeCombobox.Text;
                string query = string.Empty;
                if (type == "BreakFast")
                {
                    query = "DELETE FROM Breakfast WHERE BID = @ID";
                }
                else if (type == "Lunch")
                {
                    query = "DELETE FROM Lunch WHERE LID = @ID";
                }
                else
                {
                    query = "DELETE FROM Dinner WHERE DID = @ID";
                }

                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                using (SqlConnection connection = new SqlConnection(str))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);

                    connection.Open();
                    command.ExecuteNonQuery();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
