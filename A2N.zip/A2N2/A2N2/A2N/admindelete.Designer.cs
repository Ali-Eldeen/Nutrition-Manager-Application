﻿namespace A2N
{
    partial class admindelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button1 = new Button();
            label2 = new Label();
            idTxtbox = new TextBox();
            UsernameLabel = new Label();
            deleteBtn = new Button();
            label7 = new Label();
            typeCombobox = new ComboBox();
            backBtn = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(391, 47);
            panel1.TabIndex = 46;
            panel1.Paint += panel1_Paint;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Right;
            button1.FlatAppearance.BorderSize = 0;
            button1.Location = new Point(297, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(116, 86, 174);
            label2.Location = new Point(12, 117);
            label2.Name = "label2";
            label2.Size = new Size(193, 34);
            label2.TabIndex = 50;
            label2.Text = "Delete Meal";
            // 
            // idTxtbox
            // 
            idTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            idTxtbox.BorderStyle = BorderStyle.None;
            idTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            idTxtbox.Location = new Point(13, 207);
            idTxtbox.Margin = new Padding(4, 3, 4, 3);
            idTxtbox.Multiline = true;
            idTxtbox.Name = "idTxtbox";
            idTxtbox.Size = new Size(156, 31);
            idTxtbox.TabIndex = 52;
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.Location = new Point(13, 167);
            UsernameLabel.Margin = new Padding(4, 0, 4, 0);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(67, 23);
            UsernameLabel.TabIndex = 51;
            UsernameLabel.Text = "MealID";
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.FromArgb(116, 86, 174);
            deleteBtn.ForeColor = Color.White;
            deleteBtn.Location = new Point(61, 268);
            deleteBtn.Margin = new Padding(4, 3, 4, 3);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(247, 40);
            deleteBtn.TabIndex = 55;
            deleteBtn.Text = "Delete";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(211, 167);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(48, 23);
            label7.TabIndex = 54;
            label7.Text = "Type";
            // 
            // typeCombobox
            // 
            typeCombobox.BackColor = Color.FromArgb(230, 231, 233);
            typeCombobox.Cursor = Cursors.Hand;
            typeCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeCombobox.FlatStyle = FlatStyle.Flat;
            typeCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            typeCombobox.FormattingEnabled = true;
            typeCombobox.Items.AddRange(new object[] { "BreakFast", "Lunch", "Dinner" });
            typeCombobox.Location = new Point(206, 209);
            typeCombobox.Margin = new Padding(4, 3, 4, 3);
            typeCombobox.Name = "typeCombobox";
            typeCombobox.Size = new Size(157, 31);
            typeCombobox.TabIndex = 53;
            // 
            // backBtn
            // 
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 85, 174);
            backBtn.Location = new Point(12, 363);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(210, 56);
            backBtn.TabIndex = 56;
            backBtn.Text = "Back To Choosing Page";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // admindelete
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(391, 431);
            Controls.Add(backBtn);
            Controls.Add(deleteBtn);
            Controls.Add(label7);
            Controls.Add(typeCombobox);
            Controls.Add(idTxtbox);
            Controls.Add(UsernameLabel);
            Controls.Add(label2);
            Controls.Add(panel1);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "admindelete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "admindelete";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button1;
        private Label label2;
        private TextBox idTxtbox;
        private Label UsernameLabel;
        private Button deleteBtn;
        private Label label7;
        private ComboBox typeCombobox;
        private Button backBtn;
    }
}