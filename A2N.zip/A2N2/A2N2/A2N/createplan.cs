﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace A2N
{
    public partial class createplan : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;

        public createplan()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            panel1.MouseDown += Panel1_MouseDown;
            panel1.MouseMove += Panel1_MouseMove;
            panel1.MouseUp += Panel1_MouseUp;
        }

        protected override void WndProc(ref Message m)
        {
            const int cgrip = 16;
            const int cCaption = 32;

            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cgrip && pos.Y >= this.ClientSize.Height - cgrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                this.Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void createplan_Load(object sender, EventArgs e)
        {

        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new choosingpage().Show();
        }

        private void continueBtn_Click(object sender, EventArgs e)
        {
            bool isAllGood = true;

            if (string.IsNullOrWhiteSpace(heightTxtbox.Text) ||
                string.IsNullOrWhiteSpace(weighttxtbox.Text) ||
                string.IsNullOrWhiteSpace(ageTxtbox.Text) ||
                string.IsNullOrWhiteSpace(genderCombobox.Text) ||
                string.IsNullOrWhiteSpace(dailyactCombobox.Text))
            {
                isAllGood = false;
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (isAllGood)
            {
                try
                {
                    float height, weight;
                    int age;
                    if (!float.TryParse(heightTxtbox.Text, out height) ||
                        !float.TryParse(weighttxtbox.Text, out weight) ||
                        !int.TryParse(ageTxtbox.Text, out age))
                    {
                        MessageBox.Show("Invalid input format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    string gender = genderCombobox.Text;
                    float dailyact;
                    string goal = goalCombobox.Text;

                    if (dailyactCombobox.Text == "Little or no exercise")
                        dailyact = 1.2F;
                    else if (dailyactCombobox.Text == "Exercise 1-3 times per week")
                        dailyact = 1.375F;
                    else if (dailyactCombobox.Text == "Exercise 4-5 times per week")
                        dailyact = 1.55F;
                    else if (dailyactCombobox.Text == "Intence exercise 6-7 times per week")
                        dailyact = 1.725F;
                    else
                        dailyact = 1.9F;

                    float BMR = Program.BMRCalc(height, weight, age, gender);
                    int calories = Program.caloriescalc(BMR, dailyact, goal);
                    int reqprotiencal = Program.reqprotiencalc(weight);
                    int reqcarb = Program.reqcarb(reqprotiencal,calories,goal);
                    int reqfats = Program.reqfats(reqprotiencal, calories, goal);
                    int reqprotien = Program.reqprotien(weight);

                    string query = "UPDATE Users " +
                                   "SET Height = @Height, Weight = @Weight, Age = @Age, Gender = @Gender, DailyAct = @DailyAct, Goal = @Goal , DailyCarbohydrates = @Reqcarb , DailyFats = @Reqfats , DailyProtiens = @Reqprotien " +
                                   "WHERE UUsername = @Username";

                    string connectionString = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Height", height);
                        command.Parameters.AddWithValue("@Weight", weight);
                        command.Parameters.AddWithValue("@Age", age);
                        command.Parameters.AddWithValue("@Gender", gender);
                        command.Parameters.AddWithValue("@DailyAct", dailyact);
                        command.Parameters.AddWithValue("@Goal", goal);
                        command.Parameters.AddWithValue("@Reqcarb", reqcarb);
                        command.Parameters.AddWithValue("@Reqfats", reqfats);
                        command.Parameters.AddWithValue("@Reqprotien", reqprotien);
                        command.Parameters.AddWithValue("@Username", Program.gusername);

                        connection.Open();
                        command.ExecuteNonQuery();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                this.Hide();
                new showdailyplanform().Show();
            }
        }

        private void heightTxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dailyactCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
