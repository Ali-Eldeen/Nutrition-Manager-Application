﻿namespace A2N
{
    partial class createplan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            heightTxtbox = new TextBox();
            label2 = new Label();
            weighttxtbox = new TextBox();
            label1 = new Label();
            label4 = new Label();
            dailyactCombobox = new ComboBox();
            backBtn = new Button();
            ageTxtbox = new TextBox();
            label3 = new Label();
            label6 = new Label();
            genderCombobox = new ComboBox();
            continueBtn = new Button();
            goalCombobox = new ComboBox();
            label7 = new Label();
            panel1 = new Panel();
            button1 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(116, 86, 174);
            label5.Location = new Point(12, 54);
            label5.Name = "label5";
            label5.Size = new Size(227, 34);
            label5.TabIndex = 23;
            label5.Text = "Fill The Fields";
            // 
            // heightTxtbox
            // 
            heightTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            heightTxtbox.BorderStyle = BorderStyle.None;
            heightTxtbox.Font = new Font("MS UI Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            heightTxtbox.Location = new Point(13, 149);
            heightTxtbox.Margin = new Padding(4, 3, 4, 3);
            heightTxtbox.Multiline = true;
            heightTxtbox.Name = "heightTxtbox";
            heightTxtbox.Size = new Size(241, 28);
            heightTxtbox.TabIndex = 28;
            heightTxtbox.TextChanged += heightTxtbox_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 123);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(70, 23);
            label2.TabIndex = 27;
            label2.Text = "Height ";
            label2.Click += label2_Click;
            // 
            // weighttxtbox
            // 
            weighttxtbox.BackColor = Color.FromArgb(230, 231, 233);
            weighttxtbox.BorderStyle = BorderStyle.None;
            weighttxtbox.Font = new Font("MS UI Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            weighttxtbox.Location = new Point(365, 149);
            weighttxtbox.Margin = new Padding(4, 3, 4, 3);
            weighttxtbox.Multiline = true;
            weighttxtbox.Name = "weighttxtbox";
            weighttxtbox.Size = new Size(241, 28);
            weighttxtbox.TabIndex = 33;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(365, 123);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(66, 23);
            label1.TabIndex = 32;
            label1.Text = "weight";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 195);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(118, 23);
            label4.TabIndex = 29;
            label4.Text = "Daily Activity";
            // 
            // dailyactCombobox
            // 
            dailyactCombobox.BackColor = Color.FromArgb(230, 231, 233);
            dailyactCombobox.Cursor = Cursors.Hand;
            dailyactCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            dailyactCombobox.FlatStyle = FlatStyle.Flat;
            dailyactCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dailyactCombobox.FormattingEnabled = true;
            dailyactCombobox.Items.AddRange(new object[] { "Little or no exercise", "Exercise 1-3 times per week", "Exercise 4-5 times per week", "Intence exercise 6-7 times per week", "Very intense exercise daily or physical job" });
            dailyactCombobox.Location = new Point(12, 218);
            dailyactCombobox.Margin = new Padding(4, 3, 4, 3);
            dailyactCombobox.Name = "dailyactCombobox";
            dailyactCombobox.Size = new Size(241, 31);
            dailyactCombobox.TabIndex = 34;
            dailyactCombobox.SelectedIndexChanged += dailyactCombobox_SelectedIndexChanged;
            // 
            // backBtn
            // 
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 85, 174);
            backBtn.Location = new Point(13, 359);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(210, 56);
            backBtn.TabIndex = 35;
            backBtn.Text = "Back To Choosing Page";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // ageTxtbox
            // 
            ageTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            ageTxtbox.BorderStyle = BorderStyle.None;
            ageTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            ageTxtbox.Location = new Point(503, 218);
            ageTxtbox.Margin = new Padding(4, 3, 4, 3);
            ageTxtbox.Multiline = true;
            ageTxtbox.Name = "ageTxtbox";
            ageTxtbox.Size = new Size(103, 31);
            ageTxtbox.TabIndex = 40;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(564, 196);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(42, 23);
            label3.TabIndex = 39;
            label3.Text = "Age";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(365, 196);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(68, 23);
            label6.TabIndex = 38;
            label6.Text = "Gender";
            // 
            // genderCombobox
            // 
            genderCombobox.BackColor = Color.FromArgb(230, 231, 233);
            genderCombobox.Cursor = Cursors.Hand;
            genderCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            genderCombobox.FlatStyle = FlatStyle.Flat;
            genderCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            genderCombobox.FormattingEnabled = true;
            genderCombobox.Items.AddRange(new object[] { "Male", "Female" });
            genderCombobox.Location = new Point(359, 218);
            genderCombobox.Margin = new Padding(4, 3, 4, 3);
            genderCombobox.Name = "genderCombobox";
            genderCombobox.Size = new Size(103, 31);
            genderCombobox.TabIndex = 37;
            // 
            // continueBtn
            // 
            continueBtn.BackColor = Color.FromArgb(116, 85, 174);
            continueBtn.FlatAppearance.BorderSize = 0;
            continueBtn.FlatStyle = FlatStyle.Flat;
            continueBtn.ForeColor = Color.White;
            continueBtn.Location = new Point(396, 359);
            continueBtn.Margin = new Padding(4, 3, 4, 3);
            continueBtn.Name = "continueBtn";
            continueBtn.Size = new Size(210, 56);
            continueBtn.TabIndex = 41;
            continueBtn.Text = "Continue";
            continueBtn.UseVisualStyleBackColor = false;
            continueBtn.Click += continueBtn_Click;
            // 
            // goalCombobox
            // 
            goalCombobox.BackColor = Color.FromArgb(230, 231, 233);
            goalCombobox.Cursor = Cursors.Hand;
            goalCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            goalCombobox.FlatStyle = FlatStyle.Flat;
            goalCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            goalCombobox.FormattingEnabled = true;
            goalCombobox.Items.AddRange(new object[] { "Wieght loss ", "Maintain wieght", "Wieght stability" });
            goalCombobox.Location = new Point(13, 287);
            goalCombobox.Margin = new Padding(4, 3, 4, 3);
            goalCombobox.Name = "goalCombobox";
            goalCombobox.Size = new Size(241, 31);
            goalCombobox.TabIndex = 43;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(13, 264);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(46, 23);
            label7.TabIndex = 42;
            label7.Text = "Goal";
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(646, 47);
            panel1.TabIndex = 44;
            panel1.Paint += panel1_Paint;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Right;
            button1.FlatAppearance.BorderSize = 0;
            button1.Location = new Point(552, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // createplan
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(646, 449);
            Controls.Add(panel1);
            Controls.Add(goalCombobox);
            Controls.Add(label7);
            Controls.Add(continueBtn);
            Controls.Add(ageTxtbox);
            Controls.Add(label3);
            Controls.Add(label6);
            Controls.Add(genderCombobox);
            Controls.Add(backBtn);
            Controls.Add(dailyactCombobox);
            Controls.Add(weighttxtbox);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(heightTxtbox);
            Controls.Add(label2);
            Controls.Add(label5);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "createplan";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "createplan";
            Load += createplan_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private TextBox heightTxtbox;
        private Label label2;
        private TextBox weighttxtbox;
        private Label label1;
        private Label label4;
        private ComboBox dailyactCombobox;
        private Button backBtn;
        private TextBox ageTxtbox;
        private Label label3;
        private Label label6;
        private ComboBox genderCombobox;
        private Button continueBtn;
        private ComboBox goalCombobox;
        private Label label7;
        private Panel panel1;
        private Button button1;
    }
}