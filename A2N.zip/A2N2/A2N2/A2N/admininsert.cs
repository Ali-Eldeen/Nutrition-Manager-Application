﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace A2N
{
    public partial class admininsert : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;
        public admininsert()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            panel1.MouseDown += Panel1_MouseDown;
            panel1.MouseMove += Panel1_MouseMove;
            panel1.MouseUp += Panel1_MouseUp;
        }
        protected override void WndProc(ref Message m)
        {
            const int cgrip = 16;
            const int cCaption = 32;

            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cgrip && pos.Y >= this.ClientSize.Height - cgrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                this.Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void adminform_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void applyBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(idTxtbox.Text) ||
               string.IsNullOrWhiteSpace(nameTxtbox.Text) ||
               string.IsNullOrWhiteSpace(typeCombobox.Text) ||
               string.IsNullOrWhiteSpace(fatTxtbox.Text) ||
               string.IsNullOrWhiteSpace(carbTxtbox.Text) ||
               string.IsNullOrWhiteSpace(caloriesTxtbox.Text) ||
               string.IsNullOrWhiteSpace(protienTxtbox.Text) ||
               string.IsNullOrWhiteSpace(QuantityTxtbox.Text))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                
                int aid= Program.aID;
                int id = int.Parse(idTxtbox.Text);
                string name = nameTxtbox.Text;
                string type = typeCombobox.Text;
                float carb = float.Parse(carbTxtbox.Text);
                float calories = float.Parse(caloriesTxtbox.Text);
                float protien = float.Parse(protienTxtbox.Text);
                float fat = float.Parse(fatTxtbox.Text);
                string quantity = QuantityTxtbox.Text;
                string query = string.Empty;

                if(type == "BreakFast")
                {
                    query = "INSERT INTO Breakfast (BID, BName, BFats, BCarbohydrates, BProtiens, BCalories, BQuantity, AID_FK) " +
                               "VALUES (@ID, @Name, @Fats, @Carb, @Protien, @Calories, @Quantity, @AID)";
                }
                else if (type == "Lunch")
                {
                    query = "INSERT INTO Lunch (LID, LName, LFats, LCarbohydrates, LProtiens, LCalories, LQuantity, AID_FK) " +
                               "VALUES (@ID, @Name, @Fats, @Carb, @Protien, @Calories, @Quantity, @AID)";
                }
                else
                {
                    query = "INSERT INTO Dinner (DID, DName, DFats, DCarbohydrates, DProtiens, DCalories, DQuantity, AID_FK) " +
                               "VALUES (@ID, @Name, @Fats, @Carb, @Protien, @Calories, @Quantity, @AID)";
                }



                string connectionString = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Fats", fat);
                    command.Parameters.AddWithValue("@Carb", carb);
                    command.Parameters.AddWithValue("@Protien", protien);
                    command.Parameters.AddWithValue("@Calories", calories);
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    command.Parameters.AddWithValue("@AID", aid);


                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Data saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new adminchoose().Show();
        }
    }
}
