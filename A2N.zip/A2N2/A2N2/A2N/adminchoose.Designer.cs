﻿namespace A2N
{
    partial class adminchoose
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button1 = new Button();
            label2 = new Label();
            label3 = new Label();
            signoutBtn = new Button();
            insertBtn = new Button();
            updateBtn = new Button();
            deleteBtn = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(400, 47);
            panel1.TabIndex = 45;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Right;
            button1.FlatAppearance.BorderSize = 0;
            button1.Location = new Point(306, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(116, 86, 174);
            label2.Location = new Point(12, 76);
            label2.Name = "label2";
            label2.Size = new Size(202, 34);
            label2.TabIndex = 49;
            label2.Text = "Admin Panel";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(85, 138);
            label3.Name = "label3";
            label3.Size = new Size(227, 28);
            label3.TabIndex = 51;
            label3.Text = "Choose what you want";
            label3.Click += label3_Click;
            // 
            // signoutBtn
            // 
            signoutBtn.FlatAppearance.BorderSize = 0;
            signoutBtn.FlatStyle = FlatStyle.Flat;
            signoutBtn.ForeColor = Color.FromArgb(116, 85, 174);
            signoutBtn.Location = new Point(13, 377);
            signoutBtn.Margin = new Padding(4, 3, 4, 3);
            signoutBtn.Name = "signoutBtn";
            signoutBtn.Size = new Size(92, 56);
            signoutBtn.TabIndex = 52;
            signoutBtn.Text = "Sign out";
            signoutBtn.UseVisualStyleBackColor = true;
            signoutBtn.Click += signoutBtn_Click;
            // 
            // insertBtn
            // 
            insertBtn.BackColor = Color.FromArgb(116, 85, 174);
            insertBtn.Cursor = Cursors.Hand;
            insertBtn.FlatStyle = FlatStyle.Flat;
            insertBtn.Font = new Font("Nirmala UI", 13.8F, FontStyle.Bold);
            insertBtn.ForeColor = Color.White;
            insertBtn.Location = new Point(42, 185);
            insertBtn.Margin = new Padding(4, 3, 4, 3);
            insertBtn.Name = "insertBtn";
            insertBtn.Size = new Size(309, 46);
            insertBtn.TabIndex = 53;
            insertBtn.Text = "Insert meal";
            insertBtn.UseVisualStyleBackColor = false;
            insertBtn.Click += insertBtn_Click;
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.FromArgb(116, 85, 174);
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Nirmala UI", 13.8F, FontStyle.Bold);
            updateBtn.ForeColor = Color.White;
            updateBtn.Location = new Point(42, 255);
            updateBtn.Margin = new Padding(4, 3, 4, 3);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(309, 46);
            updateBtn.TabIndex = 54;
            updateBtn.Text = "Update meal";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updateBtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.FromArgb(116, 85, 174);
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Nirmala UI", 13.8F, FontStyle.Bold);
            deleteBtn.ForeColor = Color.White;
            deleteBtn.Location = new Point(42, 325);
            deleteBtn.Margin = new Padding(4, 3, 4, 3);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(309, 46);
            deleteBtn.TabIndex = 55;
            deleteBtn.Text = "Delete meal";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // adminchoose
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(400, 445);
            Controls.Add(deleteBtn);
            Controls.Add(updateBtn);
            Controls.Add(insertBtn);
            Controls.Add(signoutBtn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(panel1);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "adminchoose";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "adminchoose";
            Load += adminchoose_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button1;
        private Label label2;
        private Label label3;
        private Button signoutBtn;
        private Button insertBtn;
        private Button updateBtn;
        private Button deleteBtn;
    }
}