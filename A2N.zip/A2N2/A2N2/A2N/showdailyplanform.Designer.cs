﻿
namespace A2N
{
    partial class showdailyplanform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button1 = new Button();
            dailycarbTxtbox = new TextBox();
            label2 = new Label();
            dailyfatsTxtbox = new TextBox();
            label1 = new Label();
            dailyprotiensTxtbox = new TextBox();
            label3 = new Label();
            label4 = new Label();
            typeCombobox = new ComboBox();
            label5 = new Label();
            ApplyBtn = new Button();
            backBtn = new Button();
            DGV = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DGV).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(907, 47);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Right;
            button1.FlatAppearance.BorderSize = 0;
            button1.Location = new Point(813, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dailycarbTxtbox
            // 
            dailycarbTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            dailycarbTxtbox.BorderStyle = BorderStyle.None;
            dailycarbTxtbox.Font = new Font("MS UI Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dailycarbTxtbox.Location = new Point(316, 90);
            dailycarbTxtbox.Margin = new Padding(4, 3, 4, 3);
            dailycarbTxtbox.Multiline = true;
            dailycarbTxtbox.Name = "dailycarbTxtbox";
            dailycarbTxtbox.Size = new Size(133, 28);
            dailycarbTxtbox.TabIndex = 30;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(181, 93);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(127, 23);
            label2.TabIndex = 29;
            label2.Text = "Carbohydrates";
            // 
            // dailyfatsTxtbox
            // 
            dailyfatsTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            dailyfatsTxtbox.BorderStyle = BorderStyle.None;
            dailyfatsTxtbox.Font = new Font("MS UI Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dailyfatsTxtbox.Location = new Point(506, 90);
            dailyfatsTxtbox.Margin = new Padding(4, 3, 4, 3);
            dailyfatsTxtbox.Multiline = true;
            dailyfatsTxtbox.Name = "dailyfatsTxtbox";
            dailyfatsTxtbox.Size = new Size(133, 28);
            dailyfatsTxtbox.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(457, 92);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(41, 23);
            label1.TabIndex = 31;
            label1.Text = "Fats";
            // 
            // dailyprotiensTxtbox
            // 
            dailyprotiensTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            dailyprotiensTxtbox.BorderStyle = BorderStyle.None;
            dailyprotiensTxtbox.Font = new Font("MS UI Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dailyprotiensTxtbox.Location = new Point(730, 90);
            dailyprotiensTxtbox.Margin = new Padding(4, 3, 4, 3);
            dailyprotiensTxtbox.Multiline = true;
            dailyprotiensTxtbox.Name = "dailyprotiensTxtbox";
            dailyprotiensTxtbox.Size = new Size(133, 28);
            dailyprotiensTxtbox.TabIndex = 34;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(647, 92);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(75, 23);
            label3.TabIndex = 33;
            label3.Text = "Protiens";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Gray;
            label4.Location = new Point(22, 93);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(151, 23);
            label4.TabIndex = 35;
            label4.Text = "Required for day:";
            // 
            // typeCombobox
            // 
            typeCombobox.BackColor = Color.FromArgb(230, 231, 233);
            typeCombobox.Cursor = Cursors.Hand;
            typeCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeCombobox.FlatStyle = FlatStyle.Flat;
            typeCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            typeCombobox.FormattingEnabled = true;
            typeCombobox.Items.AddRange(new object[] { "BreakFast", "Lunch", "Dinner" });
            typeCombobox.Location = new Point(181, 165);
            typeCombobox.Margin = new Padding(4, 3, 4, 3);
            typeCombobox.Name = "typeCombobox";
            typeCombobox.Size = new Size(157, 31);
            typeCombobox.TabIndex = 40;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 168);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(120, 23);
            label5.TabIndex = 41;
            label5.Text = "Time selected";
            // 
            // ApplyBtn
            // 
            ApplyBtn.BackColor = Color.FromArgb(116, 85, 174);
            ApplyBtn.FlatAppearance.BorderSize = 0;
            ApplyBtn.FlatStyle = FlatStyle.Flat;
            ApplyBtn.ForeColor = Color.White;
            ApplyBtn.Location = new Point(386, 163);
            ApplyBtn.Margin = new Padding(4, 3, 4, 3);
            ApplyBtn.Name = "ApplyBtn";
            ApplyBtn.Size = new Size(133, 31);
            ApplyBtn.TabIndex = 42;
            ApplyBtn.Text = "Apply";
            ApplyBtn.UseVisualStyleBackColor = false;
            ApplyBtn.Click += ApplyBtn_Click;
            // 
            // backBtn
            // 
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 85, 174);
            backBtn.Location = new Point(13, 521);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(210, 56);
            backBtn.TabIndex = 43;
            backBtn.Text = "Back To Choosing Page";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // DGV
            // 
            DGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV.Location = new Point(12, 214);
            DGV.Name = "DGV";
            DGV.RowHeadersWidth = 51;
            DGV.Size = new Size(883, 301);
            DGV.TabIndex = 44;
            // 
            // showdailyplanform
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(907, 589);
            Controls.Add(DGV);
            Controls.Add(backBtn);
            Controls.Add(ApplyBtn);
            Controls.Add(label5);
            Controls.Add(typeCombobox);
            Controls.Add(label4);
            Controls.Add(dailyprotiensTxtbox);
            Controls.Add(label3);
            Controls.Add(dailyfatsTxtbox);
            Controls.Add(label1);
            Controls.Add(dailycarbTxtbox);
            Controls.Add(label2);
            Controls.Add(panel1);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "showdailyplanform";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "save";
            Load += save_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Panel panel1;
        private Button button1;
        private TextBox dailycarbTxtbox;
        private Label label2;
        private TextBox dailyfatsTxtbox;
        private Label label1;
        private TextBox dailyprotiensTxtbox;
        private Label label3;
        private Label label4;
        private ComboBox typeCombobox;
        private Label label5;
        private Button ApplyBtn;
        private Button backBtn;
        private DataGridView DGV;
    }
}