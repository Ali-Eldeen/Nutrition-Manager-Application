﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2N
{
    public partial class signupForm : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;

        public signupForm()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            panel1.MouseDown += Panel1_MouseDown;
            panel1.MouseMove += Panel1_MouseMove;
            panel1.MouseUp += Panel1_MouseUp;
        }

        protected override void WndProc(ref Message m)
        {
            const int cgrip = 16;
            const int cCaption = 32;

            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cgrip && pos.Y >= this.ClientSize.Height - cgrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                this.Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void createplan_Load(object sender, EventArgs e)
        {

        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new loginForm().Show();
        }

        private void signupForm_Load(object sender, EventArgs e)
        {

        }

        private void signupBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameTxtbox.Text) ||
                string.IsNullOrWhiteSpace(usernameTxtbox.Text) ||
                string.IsNullOrWhiteSpace(passwordTxtbox.Text) ||
                string.IsNullOrWhiteSpace(confirmpasswordTxtbox.Text))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (passwordTxtbox.Text == confirmpasswordTxtbox.Text)
            {
                Boolean flag = false;
                try
                {
                    string username = usernameTxtbox.Text;

                    string query = "SELECT * FROM users WHERE UUsername = @Username";

                    string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                    using (SqlConnection connection = new SqlConnection(str))
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);

                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                MessageBox.Show("Username is already used please try another one");
                                flag = true;
                            }
                        }

                        connection.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                if (!flag)
                {
                    try
                    {
                        string name = nameTxtbox.Text;
                        string username = usernameTxtbox.Text;
                        string password = passwordTxtbox.Text;

                        string query = "INSERT INTO users (UName, UUsername, UPassword) " +
                                       "VALUES (@Name, @Username, @Password)";

                        string connectionString = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Name", name);
                            command.Parameters.AddWithValue("@Username", username);
                            command.Parameters.AddWithValue("@Password", password);

                            connection.Open();
                            command.ExecuteNonQuery();
                            this.Hide();
                            new loginForm().Show();

                            connection.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Passwords is not the same");
            }
        }

        private void checkpass_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                passwordTxtbox.UseSystemPasswordChar = true;
                confirmpasswordTxtbox.UseSystemPasswordChar = true;
            }
            else
            {
                passwordTxtbox.UseSystemPasswordChar = false;
                confirmpasswordTxtbox.UseSystemPasswordChar = false;
            }
        }


        private void passwordTxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            new admininsert().Show();

        }
    }
}
