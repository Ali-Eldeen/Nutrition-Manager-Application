﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Reflection.Metadata;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ScrollBar;

namespace A2N
{
    public partial class showdailyplanform : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;

        public showdailyplanform()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            panel1.MouseDown += Panel1_MouseDown;
            panel1.MouseMove += Panel1_MouseMove;
            panel1.MouseUp += Panel1_MouseUp;
        }

        protected override void WndProc(ref Message m)
        {
            const int cgrip = 16;
            const int cCaption = 32;

            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cgrip && pos.Y >= this.ClientSize.Height - cgrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                this.Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }

        private void save_Load(object sender, EventArgs e)
        {
            try
            {

                string query = "SELECT * FROM users WHERE UUsername = @Username";
                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                using (SqlConnection connection = new SqlConnection(str))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", Program.gusername);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            dailycarbTxtbox.Text = reader["DailyCarbohydrates"].ToString();
                            dailyfatsTxtbox.Text = reader["DailyFats"].ToString();
                            dailyprotiensTxtbox.Text = reader["DailyProtiens"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void loginBtn_Click(object sender, EventArgs e)
        {


        }

        private void savebox_TextChanged(object sender, EventArgs e)
        {

        }


        private void ApplyBtn_Click(object sender, EventArgs e)
        {
            string type = typeCombobox.Text;
            if (type == "BreakFast")
            {
                string query = "SELECT BName AS Name, BFats AS Fats, BCarbohydrates AS Carbohydrates, BProtiens AS Protiens, BCalories AS Calories, BQuantity AS Quantity FROM Breakfast";
                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";
                using (SqlConnection connection = new SqlConnection(str))
                {
                    connection.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter(query, str);
                    DataTable dtbl = new DataTable();
                    sqlData.Fill(dtbl);
                    DGV.DataSource = dtbl;
                }

            }
            else if (type == "Lunch")
            {
                string query = "SELECT LName AS Name, LFats AS Fats, LCarbohydrates AS Carbohydrates, LProtiens AS Protiens, LCalories AS Calories, LQuantity AS Quantity FROM Lunch";
                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";
                using (SqlConnection connection = new SqlConnection(str))
                {
                    connection.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter(query, str);
                    DataTable dtbl = new DataTable();
                    sqlData.Fill(dtbl);
                    DGV.DataSource = dtbl;
                }
            }
            else
            {
                string query = "SELECT DName AS Name, DFats AS Fats, DCarbohydrates AS Carbohydrates, DProtiens AS Protiens, DCalories AS Calories, DQuantity AS Quantity FROM Dinner";
                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";
                using (SqlConnection connection = new SqlConnection(str))
                {
                    connection.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter(query, str);
                    DataTable dtbl = new DataTable();
                    sqlData.Fill(dtbl);
                    DGV.DataSource = dtbl;
                }
            }
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new choosingpage().Show();
        }
    }
}
