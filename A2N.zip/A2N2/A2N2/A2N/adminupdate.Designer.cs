﻿namespace A2N
{
    partial class adminupdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button3 = new Button();
            label7 = new Label();
            typeupCombobox = new ComboBox();
            idupTxtbox = new TextBox();
            UsernameLabel = new Label();
            label2 = new Label();
            retrivedataBtn = new Button();
            applyBtn = new Button();
            caloriesTxtbox = new TextBox();
            label6 = new Label();
            protienTxtbox = new TextBox();
            label5 = new Label();
            fatTxtbox = new TextBox();
            label4 = new Label();
            carbTxtbox = new TextBox();
            label3 = new Label();
            nameTxtbox = new TextBox();
            label8 = new Label();
            idTxtbox = new TextBox();
            label9 = new Label();
            backBtn = new Button();
            quantityTxtbox = new TextBox();
            label1 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button3);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(400, 47);
            panel1.TabIndex = 46;
            panel1.Paint += panel1_Paint;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Right;
            button3.FlatAppearance.BorderSize = 0;
            button3.Location = new Point(306, 0);
            button3.Name = "button3";
            button3.Size = new Size(94, 47);
            button3.TabIndex = 0;
            button3.Text = "X";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(198, 111);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(48, 23);
            label7.TabIndex = 58;
            label7.Text = "Type";
            // 
            // typeupCombobox
            // 
            typeupCombobox.BackColor = Color.FromArgb(230, 231, 233);
            typeupCombobox.Cursor = Cursors.Hand;
            typeupCombobox.DropDownStyle = ComboBoxStyle.DropDownList;
            typeupCombobox.FlatStyle = FlatStyle.Flat;
            typeupCombobox.Font = new Font("Nirmala UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            typeupCombobox.FormattingEnabled = true;
            typeupCombobox.Items.AddRange(new object[] { "BreakFast", "Lunch", "Dinner" });
            typeupCombobox.Location = new Point(198, 146);
            typeupCombobox.Margin = new Padding(4, 3, 4, 3);
            typeupCombobox.Name = "typeupCombobox";
            typeupCombobox.Size = new Size(157, 31);
            typeupCombobox.TabIndex = 57;
            // 
            // idupTxtbox
            // 
            idupTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            idupTxtbox.BorderStyle = BorderStyle.None;
            idupTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            idupTxtbox.Location = new Point(12, 144);
            idupTxtbox.Margin = new Padding(4, 3, 4, 3);
            idupTxtbox.Multiline = true;
            idupTxtbox.Name = "idupTxtbox";
            idupTxtbox.Size = new Size(157, 33);
            idupTxtbox.TabIndex = 56;
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.Location = new Point(12, 111);
            UsernameLabel.Margin = new Padding(4, 0, 4, 0);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(67, 23);
            UsernameLabel.TabIndex = 55;
            UsernameLabel.Text = "MealID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(116, 86, 174);
            label2.Location = new Point(12, 62);
            label2.Name = "label2";
            label2.Size = new Size(202, 34);
            label2.TabIndex = 59;
            label2.Text = "Update Meal";
            // 
            // retrivedataBtn
            // 
            retrivedataBtn.BackColor = Color.FromArgb(116, 86, 174);
            retrivedataBtn.ForeColor = Color.White;
            retrivedataBtn.Location = new Point(64, 191);
            retrivedataBtn.Margin = new Padding(4, 3, 4, 3);
            retrivedataBtn.Name = "retrivedataBtn";
            retrivedataBtn.Size = new Size(247, 40);
            retrivedataBtn.TabIndex = 61;
            retrivedataBtn.Text = "Retrieve data";
            retrivedataBtn.UseVisualStyleBackColor = false;
            retrivedataBtn.Click += retrivedataBtn_Click;
            // 
            // applyBtn
            // 
            applyBtn.BackColor = Color.FromArgb(116, 86, 174);
            applyBtn.ForeColor = Color.White;
            applyBtn.Location = new Point(221, 504);
            applyBtn.Margin = new Padding(4, 3, 4, 3);
            applyBtn.Name = "applyBtn";
            applyBtn.Size = new Size(166, 40);
            applyBtn.TabIndex = 76;
            applyBtn.Text = "Apply";
            applyBtn.UseVisualStyleBackColor = false;
            applyBtn.Click += applyBtn_Click;
            // 
            // caloriesTxtbox
            // 
            caloriesTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            caloriesTxtbox.BorderStyle = BorderStyle.None;
            caloriesTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            caloriesTxtbox.Location = new Point(219, 427);
            caloriesTxtbox.Margin = new Padding(4, 3, 4, 3);
            caloriesTxtbox.Multiline = true;
            caloriesTxtbox.Name = "caloriesTxtbox";
            caloriesTxtbox.Size = new Size(156, 40);
            caloriesTxtbox.TabIndex = 73;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(219, 401);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(73, 23);
            label6.TabIndex = 72;
            label6.Text = "Calories";
            // 
            // protienTxtbox
            // 
            protienTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            protienTxtbox.BorderStyle = BorderStyle.None;
            protienTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            protienTxtbox.Location = new Point(13, 427);
            protienTxtbox.Margin = new Padding(4, 3, 4, 3);
            protienTxtbox.Multiline = true;
            protienTxtbox.Name = "protienTxtbox";
            protienTxtbox.Size = new Size(156, 40);
            protienTxtbox.TabIndex = 71;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 401);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(68, 23);
            label5.TabIndex = 70;
            label5.Text = "Protien";
            // 
            // fatTxtbox
            // 
            fatTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            fatTxtbox.BorderStyle = BorderStyle.None;
            fatTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            fatTxtbox.Location = new Point(219, 361);
            fatTxtbox.Margin = new Padding(4, 3, 4, 3);
            fatTxtbox.Multiline = true;
            fatTxtbox.Name = "fatTxtbox";
            fatTxtbox.Size = new Size(156, 40);
            fatTxtbox.TabIndex = 69;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(219, 328);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(34, 23);
            label4.TabIndex = 68;
            label4.Text = "Fat";
            // 
            // carbTxtbox
            // 
            carbTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            carbTxtbox.BorderStyle = BorderStyle.None;
            carbTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            carbTxtbox.Location = new Point(13, 361);
            carbTxtbox.Margin = new Padding(4, 3, 4, 3);
            carbTxtbox.Multiline = true;
            carbTxtbox.Name = "carbTxtbox";
            carbTxtbox.Size = new Size(156, 40);
            carbTxtbox.TabIndex = 67;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 328);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(48, 23);
            label3.TabIndex = 66;
            label3.Text = "Carb";
            // 
            // nameTxtbox
            // 
            nameTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            nameTxtbox.BorderStyle = BorderStyle.None;
            nameTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            nameTxtbox.Location = new Point(219, 282);
            nameTxtbox.Margin = new Padding(4, 3, 4, 3);
            nameTxtbox.Multiline = true;
            nameTxtbox.Name = "nameTxtbox";
            nameTxtbox.Size = new Size(156, 40);
            nameTxtbox.TabIndex = 65;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(219, 249);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(96, 23);
            label8.TabIndex = 64;
            label8.Text = "MealName";
            // 
            // idTxtbox
            // 
            idTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            idTxtbox.BorderStyle = BorderStyle.None;
            idTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            idTxtbox.Location = new Point(12, 282);
            idTxtbox.Margin = new Padding(4, 3, 4, 3);
            idTxtbox.Multiline = true;
            idTxtbox.Name = "idTxtbox";
            idTxtbox.Size = new Size(156, 40);
            idTxtbox.TabIndex = 63;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 249);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(67, 23);
            label9.TabIndex = 62;
            label9.Text = "MealID";
            // 
            // backBtn
            // 
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 85, 174);
            backBtn.Location = new Point(12, 550);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(208, 42);
            backBtn.TabIndex = 77;
            backBtn.Text = "Back To Choosing Page";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // quantityTxtbox
            // 
            quantityTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            quantityTxtbox.BorderStyle = BorderStyle.None;
            quantityTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            quantityTxtbox.Location = new Point(13, 504);
            quantityTxtbox.Margin = new Padding(4, 3, 4, 3);
            quantityTxtbox.Multiline = true;
            quantityTxtbox.Name = "quantityTxtbox";
            quantityTxtbox.Size = new Size(156, 40);
            quantityTxtbox.TabIndex = 79;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 478);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(80, 23);
            label1.TabIndex = 78;
            label1.Text = "Quantity";
            // 
            // adminupdate
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(400, 604);
            Controls.Add(quantityTxtbox);
            Controls.Add(label1);
            Controls.Add(backBtn);
            Controls.Add(applyBtn);
            Controls.Add(caloriesTxtbox);
            Controls.Add(label6);
            Controls.Add(protienTxtbox);
            Controls.Add(label5);
            Controls.Add(fatTxtbox);
            Controls.Add(label4);
            Controls.Add(carbTxtbox);
            Controls.Add(label3);
            Controls.Add(nameTxtbox);
            Controls.Add(label8);
            Controls.Add(idTxtbox);
            Controls.Add(label9);
            Controls.Add(retrivedataBtn);
            Controls.Add(label2);
            Controls.Add(label7);
            Controls.Add(typeupCombobox);
            Controls.Add(idupTxtbox);
            Controls.Add(UsernameLabel);
            Controls.Add(panel1);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "adminupdate";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "adminupdate";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button3;
        private Label label7;
        private ComboBox typeupCombobox;
        private TextBox idupTxtbox;
        private Label UsernameLabel;
        private Label label2;
        private Button retrivedataBtn;
        private Button applyBtn;
        private TextBox caloriesTxtbox;
        private Label label6;
        private TextBox protienTxtbox;
        private Label label5;
        private TextBox fatTxtbox;
        private Label label4;
        private TextBox carbTxtbox;
        private Label label3;
        private TextBox nameTxtbox;
        private Label label8;
        private TextBox idTxtbox;
        private Label label9;
        private Button backBtn;
        private TextBox quantityTxtbox;
        private Label label1;
    }
}