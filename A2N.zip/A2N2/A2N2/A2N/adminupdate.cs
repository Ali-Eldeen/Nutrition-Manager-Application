﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace A2N
{
    public partial class adminupdate : Form
    {
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;
        public adminupdate()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            panel1.MouseDown += Panel1_MouseDown;
            panel1.MouseMove += Panel1_MouseMove;
            panel1.MouseUp += Panel1_MouseUp;
        }

        protected override void WndProc(ref Message m)
        {
            const int cgrip = 16;
            const int cCaption = 32;

            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {
                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cgrip && pos.Y >= this.ClientSize.Height - cgrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastCursor = Cursor.Position;
                lastForm = this.Location;
            }
        }

        private void Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = Cursor.Position.X - lastCursor.X;
                int deltaY = Cursor.Position.Y - lastCursor.Y;
                this.Location = new Point(lastForm.X + deltaX, lastForm.Y + deltaY);
            }
        }

        private void Panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new adminchoose().Show();
        }

        private void applyBtn_Click(object sender, EventArgs e)
        {
            try
            {

                int aid = Program.aID;
                string idold = idupTxtbox.Text;
                string typeold = typeupCombobox.Text;
                int id = int.Parse(idTxtbox.Text);
                string name = nameTxtbox.Text;
                float carb = float.Parse(carbTxtbox.Text);
                float calories = float.Parse(caloriesTxtbox.Text);
                float protien = float.Parse(protienTxtbox.Text);
                float fat = float.Parse(fatTxtbox.Text);
                string query = string.Empty;
                string quantity = quantityTxtbox.Text;

                if (typeold == "BreakFast")
                {
                    query = "UPDATE Breakfast " +
                                "SET BID = @ID, BName = @Name, BFats = @Fat, BCarbohydrates = @Carb, BProtiens = @Protien, BCalories = @Calories, BQuantity = @Quantity, AID_FK = @AID " +
                                "WHERE BID = @ID";
                }
                else if (typeold == "Lunch")
                {
                    query = "UPDATE Lunch " +
                                "SET LID = @ID, LName = @Name, LFats = @Fat, LCarbohydrates = @Carb, LProtiens = @Protien, LCalories = @Calories, LQuantity = @Quantity , AID_FK = @AID " +
                                "WHERE LID = @ID";
                }
                else
                {
                    query = "UPDATE Dinner " +
                                "SET DID = @ID, DName = @Name, DFats = @Fat, DCarbohydrates = @Carb, DProtiens = @Protien, DCalories = @Calories, DQuantity = @Quantity , AID_FK = @AID " +
                                "WHERE DID = @ID";
                }

                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";
                using (SqlConnection connection = new SqlConnection(str))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", id);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Fat", fat);
                    command.Parameters.AddWithValue("@Carb", carb);
                    command.Parameters.AddWithValue("@Protien", protien);
                    command.Parameters.AddWithValue("@Calories", calories);
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    command.Parameters.AddWithValue("@AID", aid);

                    connection.Open();
                    command.ExecuteNonQuery();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private void retrivedataBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string idold = idupTxtbox.Text;
                string typeold = typeupCombobox.Text;
                string query = string.Empty;
                if(typeold == "BreakFast")
                {
                    query = "SELECT * FROM Breakfast WHERE BID = @ID";
                }
                else if (typeold == "Lunch")
                {
                    query = "SELECT * FROM Breakfast WHERE LID = @ID";
                }
                else
                {
                    query = "SELECT * FROM Breakfast WHERE DID = @ID";
                }

                string str = "server=ALOKA22TRIKA;database=A2N;UID=AAA;password=123";

                using (SqlConnection connection = new SqlConnection(str))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", idold);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string id = string.Empty;
                            string name = string.Empty;
                            string fats = string.Empty;
                            string carb = string.Empty;
                            string protien = string.Empty;
                            string calories = string.Empty;
                            string quantity = string.Empty;

                            if (typeold == "BreakFast")
                            {
                                id = reader["BID"].ToString();
                                name = reader["BName"].ToString();
                                fats = reader["BFats"].ToString();
                                carb = reader["BCarbohydrates"].ToString();
                                protien = reader["BProtiens"].ToString();
                                calories = reader["BCalories"].ToString();
                                quantity = reader["BQuantity"].ToString();
                            }
                            else if (typeold == "Lunch")
                            {
                                id = reader["LID"].ToString();
                                name = reader["LName"].ToString();
                                fats = reader["LFats"].ToString();
                                carb = reader["LCarbohydrates"].ToString();
                                protien = reader["LProtiens"].ToString();
                                calories = reader["LCalories"].ToString();
                                quantity = reader["LQuantity"].ToString();
                            }
                            else
                            {
                                id = reader["DID"].ToString();
                                name = reader["DName"].ToString();
                                fats = reader["DFats"].ToString();
                                carb = reader["DCarbohydrates"].ToString();
                                protien = reader["DProtiens"].ToString();
                                calories = reader["DCalories"].ToString();
                                quantity = reader["DQuantity"].ToString();
                            }
                            idTxtbox.Text = id;
                            nameTxtbox.Text = name;
                            fatTxtbox.Text = fats;
                            carbTxtbox.Text = carb;
                            protienTxtbox.Text = protien;
                            caloriesTxtbox.Text = calories;
                            quantityTxtbox.Text = quantity;
                        }
                        else
                        {
                            MessageBox.Show("Not Found");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
