﻿namespace A2N
{
    partial class choosingpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            seebtn = new Button();
            Createbtn = new Button();
            label1 = new Label();
            label5 = new Label();
            signoutBtn = new Button();
            panel1 = new Panel();
            button1 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // seebtn
            // 
            seebtn.BackColor = Color.FromArgb(116, 85, 174);
            seebtn.Cursor = Cursors.Hand;
            seebtn.FlatStyle = FlatStyle.Flat;
            seebtn.Font = new Font("Nirmala UI", 13.8F, FontStyle.Bold);
            seebtn.ForeColor = Color.White;
            seebtn.Location = new Point(46, 230);
            seebtn.Margin = new Padding(4, 3, 4, 3);
            seebtn.Name = "seebtn";
            seebtn.Size = new Size(309, 46);
            seebtn.TabIndex = 4;
            seebtn.Text = "See Your Plan";
            seebtn.UseVisualStyleBackColor = false;
            seebtn.Click += seebtn_Click;
            // 
            // Createbtn
            // 
            Createbtn.BackColor = Color.FromArgb(116, 85, 174);
            Createbtn.Cursor = Cursors.Hand;
            Createbtn.FlatStyle = FlatStyle.Flat;
            Createbtn.Font = new Font("Nirmala UI", 13.8F, FontStyle.Bold);
            Createbtn.ForeColor = Color.White;
            Createbtn.Location = new Point(46, 169);
            Createbtn.Margin = new Padding(4, 3, 4, 3);
            Createbtn.Name = "Createbtn";
            Createbtn.Size = new Size(309, 46);
            Createbtn.TabIndex = 3;
            Createbtn.Text = "Create Plan";
            Createbtn.UseVisualStyleBackColor = false;
            Createbtn.Click += loginBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(59, 23);
            label1.TabIndex = 5;
            label1.Text = "label1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(116, 86, 174);
            label5.Location = new Point(58, 86);
            label5.Name = "label5";
            label5.Size = new Size(272, 34);
            label5.TabIndex = 22;
            label5.Text = "Welcome To A2N";
            // 
            // signoutBtn
            // 
            signoutBtn.FlatAppearance.BorderSize = 0;
            signoutBtn.FlatStyle = FlatStyle.Flat;
            signoutBtn.ForeColor = Color.FromArgb(116, 85, 174);
            signoutBtn.Location = new Point(13, 362);
            signoutBtn.Margin = new Padding(4, 3, 4, 3);
            signoutBtn.Name = "signoutBtn";
            signoutBtn.Size = new Size(92, 56);
            signoutBtn.TabIndex = 36;
            signoutBtn.Text = "Sign out";
            signoutBtn.UseVisualStyleBackColor = true;
            signoutBtn.Click += signoutBtn_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(400, 47);
            panel1.TabIndex = 37;
            panel1.Paint += panel1_Paint;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Right;
            button1.FlatAppearance.BorderSize = 0;
            button1.ForeColor = Color.FromArgb(164, 165, 169);
            button1.Location = new Point(306, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // choosingpage
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(400, 445);
            Controls.Add(panel1);
            Controls.Add(signoutBtn);
            Controls.Add(label5);
            Controls.Add(label1);
            Controls.Add(seebtn);
            Controls.Add(Createbtn);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "choosingpage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "choosingpage";
            Load += choosingpage_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button seebtn;
        private Button Createbtn;
        private Label label1;
        private Label label5;
        private Button signoutBtn;
        private Panel panel1;
        private Button button1;
    }
}