using System.IO;

namespace A2N
{
    internal static class Program
    {
        public static string gusername = "";
        public static string gpassword = "";
        public static int aID = 0;

        public static float BMRCalc(float Hieght, float Wieght, int Age, string Gender)
        {
            if (Gender == "Male")
            {
                float BMR = (float)(6.25 * Hieght + 10 * Wieght - 5 * Age + 5);
                return BMR;
            }
            else
            {
                float BMR = (float)(6.25 * Hieght + 10 * Wieght - 5 * Age - 161);
                return BMR;
            }
        }
        public static int caloriescalc(float BMR,float Dailyact, string Goal)
        {
            if(Goal == "Wieght loss")
                return (int)(BMR * Dailyact) - 500;
            else if (Goal == "Maintain wieght")
                return (int)(BMR * Dailyact) + 500;
            else
                return (int)(BMR * Dailyact);
        }
        public static int reqprotiencalc(float Wieght)
        {
            return (int)(Wieght * 2.2)*4;
        }
        public static int reqcarb(int Protien, int Calories, string Goal)
        {
            if (Goal == "Wieght loss")
                return (int)(Calories - Protien) / 2 / 4;
            else if (Goal == "Maintain wieght")
                return (int)(Calories - Protien) * 65 / 100 / 4;
            else
                return (int)(Calories - Protien) * 55 / 100 / 4;
        }
        public static int reqfats(int Protien, int Calories, string Goal)
        {
            if (Goal == "Wieght loss")
                return (int)(Calories - Protien) / 2 /9;
            else if (Goal == "Maintain wieght")
                return (int)(Calories - Protien) * 35 / 100 / 9;
            else
                return (int)(Calories - Protien) * 45 / 100 / 9;
        }
        public static int reqprotien(float Wieght)
        {
            return (int)(Wieght * 2.2);
        }

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new logsignForm());
        }
    }
}