﻿namespace A2N
{
    partial class signupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            passwordTxtbox = new TextBox();
            usernameTxtbox = new TextBox();
            PasswordLabel = new Label();
            UsernameLabel = new Label();
            confirmpasswordTxtbox = new TextBox();
            label1 = new Label();
            nameTxtbox = new TextBox();
            label2 = new Label();
            signupBtn = new Button();
            backBtn = new Button();
            label5 = new Label();
            checkBox1 = new CheckBox();
            button1 = new Button();
            label6 = new Label();
            panel1 = new Panel();
            button2 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // passwordTxtbox
            // 
            passwordTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            passwordTxtbox.BorderStyle = BorderStyle.None;
            passwordTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            passwordTxtbox.Location = new Point(54, 267);
            passwordTxtbox.Margin = new Padding(4, 3, 4, 3);
            passwordTxtbox.Multiline = true;
            passwordTxtbox.Name = "passwordTxtbox";
            passwordTxtbox.PasswordChar = '*';
            passwordTxtbox.Size = new Size(241, 28);
            passwordTxtbox.TabIndex = 9;
            passwordTxtbox.TextChanged += passwordTxtbox_TextChanged;
            // 
            // usernameTxtbox
            // 
            usernameTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            usernameTxtbox.BorderStyle = BorderStyle.None;
            usernameTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            usernameTxtbox.Location = new Point(54, 210);
            usernameTxtbox.Margin = new Padding(4, 3, 4, 3);
            usernameTxtbox.Multiline = true;
            usernameTxtbox.Name = "usernameTxtbox";
            usernameTxtbox.Size = new Size(241, 28);
            usernameTxtbox.TabIndex = 8;
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.Location = new Point(54, 241);
            PasswordLabel.Margin = new Padding(4, 0, 4, 0);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(84, 23);
            PasswordLabel.TabIndex = 7;
            PasswordLabel.Text = "Password";
            // 
            // UsernameLabel
            // 
            UsernameLabel.AutoSize = true;
            UsernameLabel.Location = new Point(54, 184);
            UsernameLabel.Margin = new Padding(4, 0, 4, 0);
            UsernameLabel.Name = "UsernameLabel";
            UsernameLabel.Size = new Size(89, 23);
            UsernameLabel.TabIndex = 6;
            UsernameLabel.Text = "Username";
            // 
            // confirmpasswordTxtbox
            // 
            confirmpasswordTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            confirmpasswordTxtbox.BorderStyle = BorderStyle.None;
            confirmpasswordTxtbox.Font = new Font("MS UI Gothic", 16.2F);
            confirmpasswordTxtbox.Location = new Point(54, 323);
            confirmpasswordTxtbox.Margin = new Padding(4, 3, 4, 3);
            confirmpasswordTxtbox.Multiline = true;
            confirmpasswordTxtbox.Name = "confirmpasswordTxtbox";
            confirmpasswordTxtbox.PasswordChar = '*';
            confirmpasswordTxtbox.Size = new Size(241, 28);
            confirmpasswordTxtbox.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(54, 297);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(157, 23);
            label1.TabIndex = 10;
            label1.Text = "Confirm password";
            // 
            // nameTxtbox
            // 
            nameTxtbox.BackColor = Color.FromArgb(230, 231, 233);
            nameTxtbox.BorderStyle = BorderStyle.None;
            nameTxtbox.Font = new Font("MS UI Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nameTxtbox.Location = new Point(54, 153);
            nameTxtbox.Margin = new Padding(4, 3, 4, 3);
            nameTxtbox.Multiline = true;
            nameTxtbox.Name = "nameTxtbox";
            nameTxtbox.Size = new Size(241, 28);
            nameTxtbox.TabIndex = 13;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(54, 127);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(57, 23);
            label2.TabIndex = 12;
            label2.Text = "Name";
            // 
            // signupBtn
            // 
            signupBtn.BackColor = Color.FromArgb(116, 86, 174);
            signupBtn.Cursor = Cursors.Hand;
            signupBtn.FlatAppearance.BorderSize = 0;
            signupBtn.FlatStyle = FlatStyle.Flat;
            signupBtn.ForeColor = Color.White;
            signupBtn.Location = new Point(48, 417);
            signupBtn.Margin = new Padding(4, 3, 4, 3);
            signupBtn.Name = "signupBtn";
            signupBtn.Size = new Size(247, 40);
            signupBtn.TabIndex = 18;
            signupBtn.Text = "SIGN UP";
            signupBtn.UseVisualStyleBackColor = false;
            signupBtn.Click += signupBtn_Click;
            // 
            // backBtn
            // 
            backBtn.FlatAppearance.BorderSize = 0;
            backBtn.FlatStyle = FlatStyle.Flat;
            backBtn.ForeColor = Color.FromArgb(116, 85, 174);
            backBtn.Location = new Point(81, 544);
            backBtn.Margin = new Padding(4, 3, 4, 3);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(173, 33);
            backBtn.TabIndex = 19;
            backBtn.Text = "Back To LOGIN";
            backBtn.UseVisualStyleBackColor = true;
            backBtn.Click += backBtn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MS UI Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(116, 86, 174);
            label5.Location = new Point(23, 62);
            label5.Name = "label5";
            label5.Size = new Size(272, 34);
            label5.TabIndex = 20;
            label5.Text = "A2N Registration";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Cursor = Cursors.Hand;
            checkBox1.FlatStyle = FlatStyle.Flat;
            checkBox1.Location = new Point(144, 357);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(151, 27);
            checkBox1.TabIndex = 21;
            checkBox1.Text = "Show Password";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.FromArgb(116, 86, 174);
            button1.Location = new Point(48, 463);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.Size = new Size(247, 40);
            button1.TabIndex = 22;
            button1.Text = "Clear";
            button1.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(68, 518);
            label6.Name = "label6";
            label6.Size = new Size(214, 23);
            label6.TabIndex = 23;
            label6.Text = "Already Have An Account";
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(button2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(356, 47);
            panel1.TabIndex = 24;
            panel1.Paint += panel1_Paint_1;
            // 
            // button2
            // 
            button2.Dock = DockStyle.Right;
            button2.FlatAppearance.BorderSize = 0;
            button2.Location = new Point(262, 0);
            button2.Name = "button2";
            button2.Size = new Size(94, 47);
            button2.TabIndex = 0;
            button2.Text = "X";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // signupForm
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(356, 599);
            Controls.Add(panel1);
            Controls.Add(label6);
            Controls.Add(button1);
            Controls.Add(checkBox1);
            Controls.Add(label5);
            Controls.Add(backBtn);
            Controls.Add(signupBtn);
            Controls.Add(nameTxtbox);
            Controls.Add(label2);
            Controls.Add(confirmpasswordTxtbox);
            Controls.Add(label1);
            Controls.Add(passwordTxtbox);
            Controls.Add(usernameTxtbox);
            Controls.Add(PasswordLabel);
            Controls.Add(UsernameLabel);
            Font = new Font("Nirmala UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "signupForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "signupForm";
            Load += signupForm_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox passwordTxtbox;
        private TextBox usernameTxtbox;
        private Label PasswordLabel;
        private Label UsernameLabel;
        private TextBox confirmpasswordTxtbox;
        private Label label1;
        private TextBox nameTxtbox;
        private Label label2;
        private Button signupBtn;
        private Button backBtn;
        private Label label5;
        private CheckBox checkBox1;
        private Button button1;
        private Label label6;
        private Panel panel1;
        private Button button2;
    }
}